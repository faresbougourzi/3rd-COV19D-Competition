# 2nd-COV19D-Competition

This Repisotory Contains our Proposed approaches for 2nd COV19D competition.
